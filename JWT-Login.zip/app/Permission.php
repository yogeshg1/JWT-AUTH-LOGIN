<?php
/**
 * Created by PhpStorm.
 * User: IGE OLUWASEGUN
 * Date: 07/07/2018
 * Time: 11:44
 */

namespace App;


use Zizaco\Entrust\EntrustPermission;

class Permission extends EntrustPermission
{

}