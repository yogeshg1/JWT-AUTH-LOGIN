<?php
/**
 * Created by PhpStorm.
 * User: IGE OLUWASEGUN
 * Date: 07/07/2018
 * Time: 11:45
 */

namespace App;


use Zizaco\Entrust\EntrustRole;

class Role extends EntrustRole
{

}