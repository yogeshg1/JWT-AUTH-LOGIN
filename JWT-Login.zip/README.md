# Role-Based-Authentication-in-laravel-with-JWT
A role based authentication in laravel with JSON Web Token (JWT)
